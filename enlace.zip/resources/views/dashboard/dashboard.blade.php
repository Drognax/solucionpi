@extends('layouts.dashboard')






@section('content')

@include('errors')
 dashboard
@endsection